#!/bin/bash

echo "Current conda version:"
conda --version

echo "Updating conda..."
conda update conda -y

#Create environment 'star_env' and install python 3.7
echo "Creating 'star_env' and installing python 3.7"
conda create -n star_env
conda install -n star_env python=3.7

#Activating the environment
echo "Activating 'star_env' environment..."
conda activate star_env

#Install required packages / library
conda install -n star_env numpy
conda install -n star_env conda-forge::matplotlib
conda install -n star_env seaborn
conda install -n star_env pandas

#Check installed packages
echo "Packages installed in 'star_env' environment"
conda list




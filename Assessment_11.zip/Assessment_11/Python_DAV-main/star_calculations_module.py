#star_calculations_module.py

import numpy as np

def distance_from_earth_parsecs(Mv,m):
    """
    Calculate the distance in parsecs between each star and Earth based on their Absolute Magnitude and apparent magnitude.
    """
    distance_parsecs = np.power(10, (m - Mv + 5) / 5)
    return distance_parsecs

def parsecs_to_lightYears(distance_parsec):
    """
    Convert the distance in parsecs to light years units
    """
    conversion_factor = 3.2616
    distance_lightYears = distance_parsec * conversion_factor
    return distance_lightYears
    